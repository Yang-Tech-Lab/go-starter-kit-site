-- Seed data for the SQL exercises.
--
-- Run against a fresh database (do NOT run against your real app.db):
--   sqlite3 exercises.db < seed.sql
-- or open exercises.db in DB Browser for SQLite and run this file.
--
-- It creates the same tables as the starter's migration, then inserts
-- small sample data sets. Safe to re-run: it drops the tables first.

DROP TABLE IF EXISTS notes;
DROP TABLE IF EXISTS links;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    email         TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at    TEXT NOT NULL
);

CREATE TABLE links (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    code       TEXT NOT NULL UNIQUE,
    target     TEXT NOT NULL,
    visits     INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

CREATE TABLE notes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    title      TEXT NOT NULL,
    body       TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- Four users. Margaret (id 4) has no links and no notes on purpose:
-- she is the test case for LEFT JOIN exercises.
INSERT INTO users (id, email, password_hash, created_at) VALUES
(1, 'ada@example.com',      'hashed', '2026-01-05T09:00:00Z'),
(2, 'grace@example.com',    'hashed', '2026-01-12T10:30:00Z'),
(3, 'linus@example.com',    'hashed', '2026-02-01T08:15:00Z'),
(4, 'margaret@example.com', 'hashed', '2026-02-20T14:45:00Z');

INSERT INTO links (id, user_id, code, target, visits, created_at) VALUES
(1, 1, 'abc123', 'https://example.com/blog',  42, '2026-01-06T09:10:00Z'),
(2, 1, 'def456', 'https://example.com/docs',   7, '2026-01-20T11:00:00Z'),
(3, 2, 'ghi789', 'https://example.com/shop', 128, '2026-01-15T16:20:00Z'),
(4, 2, 'jkl012', 'https://example.com/about',  3, '2026-02-03T09:00:00Z'),
(5, 3, 'mno345', 'https://example.com/blog',  55, '2026-02-02T12:00:00Z');

INSERT INTO notes (id, user_id, title, body, created_at, updated_at) VALUES
(1, 1, 'Groceries',    'milk, eggs, bread',                 '2026-01-07T08:00:00Z', '2026-01-07T08:00:00Z'),
(2, 1, 'Ideas',        'build a link shortener in Go',      '2026-01-25T20:00:00Z', '2026-01-26T09:00:00Z'),
(3, 2, 'TODO',         'ship the landing page',             '2026-01-16T10:00:00Z', '2026-01-18T10:00:00Z'),
(4, 3, 'Reading list', 'The Go Programming Language',       '2026-02-05T19:30:00Z', '2026-02-05T19:30:00Z'),
(5, 3, 'Workout',      'run 5k on Saturday',                '2026-02-10T07:00:00Z', '2026-02-11T07:00:00Z'),
(6, 3, 'Go tips',      'slices, maps, and interfaces',      '2026-02-12T21:00:00Z', '2026-02-12T21:00:00Z');
