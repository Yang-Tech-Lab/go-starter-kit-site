-- SQL Exercises — solutions.
-- Run them against exercises.db (created by seed.sql) to check your work.
-- There is often more than one correct query; these are the reference answers.

-- 1. Basics: every user, oldest account first.
SELECT id, email, created_at
FROM users
ORDER BY created_at ASC;

-- 2. Count: total users. (Answer on the seed data: 4.)
SELECT COUNT(*) AS user_count
FROM users;

-- 3. Links with more than 10 visits, most-visited first.
SELECT code, target, visits
FROM links
WHERE visits > 10
ORDER BY visits DESC;

-- 4. The 3 most-visited links.
SELECT code, visits
FROM links
ORDER BY visits DESC
LIMIT 3;

-- 5. Each link with its owner's email.
SELECT u.email, l.code, l.visits
FROM links AS l
INNER JOIN users AS u ON u.id = l.user_id
ORDER BY l.visits DESC;

-- 6. Link count per user, including users with zero links.
--    COUNT(l.id) counts only matched rows; COUNT(*) would count 1 for
--    users with no links because LEFT JOIN still produces a row.
SELECT u.email, COUNT(l.id) AS link_count
FROM users AS u
LEFT JOIN links AS l ON l.user_id = u.id
GROUP BY u.id, u.email
ORDER BY link_count DESC;

-- 7. Users with more than one note.
SELECT u.email, COUNT(n.id) AS note_count
FROM users AS u
INNER JOIN notes AS n ON n.user_id = u.id
GROUP BY u.id, u.email
HAVING COUNT(n.id) > 1;

-- 8. Average visits per link, rounded to one decimal.
SELECT ROUND(AVG(visits), 1) AS avg_visits
FROM links;

-- 9. Notes whose body mentions 'Go' (LIKE is case-insensitive for ASCII
--    in SQLite by default).
SELECT n.title, u.email
FROM notes AS n
INNER JOIN users AS u ON u.id = n.user_id
WHERE n.body LIKE '%Go%';

-- 10. Signups per day.
SELECT DATE(created_at) AS signup_date, COUNT(*) AS signups
FROM users
GROUP BY DATE(created_at)
ORDER BY signup_date;

-- 11. Links above the average visit count.
SELECT u.email, l.code
FROM links AS l
INNER JOIN users AS u ON u.id = l.user_id
WHERE l.visits > (SELECT AVG(visits) FROM links);

-- 12. Each user's most recently updated note.
--     ROW_NUMBER() numbers notes per user; the outer query keeps #1.
SELECT email, title, updated_at
FROM (
    SELECT
        u.email AS email,
        n.title AS title,
        n.updated_at AS updated_at,
        ROW_NUMBER() OVER (
            PARTITION BY n.user_id
            ORDER BY n.updated_at DESC, n.id DESC
        ) AS rn
    FROM notes AS n
    INNER JOIN users AS u ON u.id = n.user_id
)
WHERE rn = 1;
