# SQL Exercises

Twelve progressive exercises on the starter's own schema — the same
`users`, `links`, and `notes` tables the API uses. They cover the SQL
you will actually write while building on this starter: filtering,
joins, aggregation, subqueries, and window functions.

## Setup

You need a SQLite database with sample data. From this directory:

```bash
# With the sqlite3 command-line tool:
sqlite3 exercises.db < seed.sql
sqlite3 exercises.db

# Without the CLI, open exercises.db in DB Browser for SQLite
# (free, sqlitebrowser.org) and run seed.sql there.
```

`seed.sql` creates the tables and inserts 4 users, 5 links, and 6 notes.
It is safe to re-run — it drops the tables first. Do **not** run it
against your real `app.db`; use a separate `exercises.db` file.

## How to work through them

1. Open `exercises.sql` and write your query under each prompt.
2. Run it: `sqlite3 exercises.db < exercises.sql` (or paste queries
   into the sqlite3 prompt / DB Browser one at a time).
3. Check against `solutions.sql` — but try first. There is often more
   than one correct query; the solutions are reference answers.

## The exercises

| # | Topic | Skills |
| - | ----- | ------ |
| 1 | List users, oldest first | SELECT, ORDER BY |
| 2 | Count users | COUNT(*) |
| 3 | Popular links | WHERE, ORDER BY DESC |
| 4 | Top 3 links | ORDER BY DESC, LIMIT |
| 5 | Links with owner emails | INNER JOIN |
| 6 | Link count per user (incl. zero) | LEFT JOIN, COUNT, GROUP BY |
| 7 | Users with 2+ notes | GROUP BY, HAVING |
| 8 | Average visits, rounded | AVG, ROUND, alias |
| 9 | Search note bodies | LIKE, JOIN |
| 10 | Signups per day | DATE(), GROUP BY |
| 11 | Above-average links | Scalar subquery |
| 12 | Latest note per user | Window functions |

## Tips

- `created_at` is RFC 3339 text, so SQLite's date functions work on it
  directly: `DATE(created_at)`, `strftime('%Y-%m', created_at)`.
- `COUNT(l.id)` vs `COUNT(*)`: after a LEFT JOIN, `COUNT(*)` counts the
  row even when there is no match; `COUNT(l.id)` counts only real
  matches. Exercise 6 exists to make you feel that difference.
- SQLite's `LIKE` is case-insensitive for ASCII by default.
- Stuck on window functions (exercise 12)? Think of `ROW_NUMBER()`
  as numbering rows inside each user's group, then filter to row 1.
