-- SQL Exercises — work through these against exercises.db
-- (created by seed.sql). Write your query under each prompt.
-- Solutions are in solutions.sql; try each one before peeking.
--
-- Tables: users (id, email, password_hash, created_at)
--         links (id, user_id, code, target, visits, created_at)
--         notes (id, user_id, title, body, created_at, updated_at)

-- 1. Basics: list every user (id, email, created_at), oldest account first.
--    Skills: SELECT, ORDER BY.


-- 2. Count: how many users are there in total?
--    Skills: COUNT(*).


-- 3. Filtering: list the code, target, and visits of every link with more
--    than 10 visits, most-visited first.
--    Skills: WHERE, ORDER BY DESC.


-- 4. Top N: what are the 3 most-visited links? Return code and visits.
--    Skills: ORDER BY DESC, LIMIT.


-- 5. JOIN: for each link, show the owner's email, the code, and the visits.
--    Order by visits descending.
--    Skills: INNER JOIN.


-- 6. Aggregation: how many links does each user own? Show email and count,
--    including users with zero links.
--    Skills: LEFT JOIN, COUNT(), GROUP BY.


-- 7. Aggregation with HAVING: which users have written more than one note?
--    Show email and note count.
--    Skills: JOIN, GROUP BY, HAVING.


-- 8. Averages: what is the average number of visits per link? Round it to
--    one decimal place and name the column avg_visits.
--    Skills: AVG(), ROUND(), column alias.


-- 9. Text search: find all notes whose body mentions 'Go'
--    (case-insensitive). Return the note title and the owner's email.
--    Skills: LIKE, JOIN.


-- 10. Grouping by date: how many users signed up on each day? Show the
--     date and the count, ordered by date.
--     Hint: created_at is RFC 3339 text; DATE(created_at) extracts the day.
--     Skills: DATE(), GROUP BY.


-- 11. Subquery: list the email and code of every link whose visits are
--     above the average visits across all links.
--     Skills: scalar subquery in WHERE.


-- 12. Window function: for each user, show their most recently updated
--     note (title + updated_at). Users with no notes are skipped.
--     Hint: ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY updated_at DESC).
--     Skills: window functions, subquery filtering on row number.
